package com.gilbertomorales.portaria.dto;

public record DTOTeste() {
}
