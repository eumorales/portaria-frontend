package com.gilbertomorales.portaria.model.enums;

public enum TipoItem {
    CHAVE,
    CONTROLE,
    OUTRO
}
