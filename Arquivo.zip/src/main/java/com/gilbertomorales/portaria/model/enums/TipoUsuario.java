package com.gilbertomorales.portaria.model.enums;

public enum TipoUsuario {
    ALUNO,
    PROFESSOR,
    PORTEIRO
}
